Downloading session-logger
Eszip extracted successfully inside path /home/deno
