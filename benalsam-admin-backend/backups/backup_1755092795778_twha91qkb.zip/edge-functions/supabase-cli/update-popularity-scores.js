Downloading update-popularity-scores
Eszip extracted successfully inside path /home/deno
