Downloading send-notification
Eszip extracted successfully inside path /home/deno
