Downloading auto-deactivate-listings
Eszip extracted successfully inside path /home/deno
