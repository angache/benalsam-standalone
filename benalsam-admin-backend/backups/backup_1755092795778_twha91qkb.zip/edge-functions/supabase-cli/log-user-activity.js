Downloading log-user-activity
Eszip extracted successfully inside path /home/deno
