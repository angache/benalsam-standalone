Downloading increment-profile-view
Eszip extracted successfully inside path /home/deno
