Downloading calculate-trust-score
Eszip extracted successfully inside path /home/deno
